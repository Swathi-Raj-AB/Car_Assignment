import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CarDetsComponent } from './car-dets/car-dets.component';
import { HomeCarComponent } from './home-car/home-car.component';

const routes: Routes = [
  {path:'',redirectTo:'/',pathMatch:'full'},
  {path:'cars',component:HomeCarComponent},
  {path:'cars/:image/:name/:model/:speed/:color',component:CarDetsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

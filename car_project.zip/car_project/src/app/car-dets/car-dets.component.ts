import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-car-dets',
  templateUrl: './car-dets.component.html',
  styleUrls: ['./car-dets.component.css']
})
export class CarDetsComponent {
  public carImage:any;
  public carName:any;
  public carModel:any;
  public carSpeed:any;
  public carColor:any;
  
  constructor(private route : ActivatedRoute){

  }
  ngOnInit()
  {
    let image= this.route.snapshot.paramMap.get('image');
    this.carImage=image;

    let name= this.route.snapshot.paramMap.get('name');
    this.carName=name;

    let model = this.route.snapshot.paramMap.get('model');
    this.carModel=model;

    let speed = this.route.snapshot.paramMap.get('speed');
    this.carSpeed=speed;
    
    let color = this.route.snapshot.paramMap.get('color');
    this.carColor=color;

  }
}

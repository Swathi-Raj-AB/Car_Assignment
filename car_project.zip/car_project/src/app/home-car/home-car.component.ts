import { Component } from '@angular/core';
import { FormBuilder,FormGroup} from'@angular/forms';
import { Router } from '@angular/router';
import { ApiService} from '../shared/api.service';
import {CarModel} from './home-car.model';

@Component({
  selector: 'app-home-car',
  templateUrl: './home-car.component.html',
  styleUrls: ['./home-car.component.css']
})
export class HomeCarComponent {
  formValue !: FormGroup;
  carModelObj: CarModel = new CarModel();
  carData: any;
  showAdd !:boolean;
  showUpdate !: boolean;
  

  constructor(private formBuilder: FormBuilder
    , private api: ApiService,
    private router:Router) {

  }

  fetchCar(cars:any)
  {
    this.router.navigate(['/cars',cars.image,cars.name,cars.model,cars.speed,cars.color]);
  }

  ngOnInit() {
    this.router.routeReuseStrategy.shouldReuseRoute=()=> false;
    this.formValue = this.formBuilder.group({
      image:[''],
      name:[''],
      model:[''],
      speed:[],
      color:['']
    })
    this.getAllCars();
  }

  clickAddCar(){
    this.formValue.reset();
    this.showAdd=true;
    this.showUpdate=false;
  }

  postCarDetails() {
    this.carModelObj.image = this.formValue.value.image;
    this.carModelObj.name = this.formValue.value.name;
    this.carModelObj.model = this.formValue.value.model;
    this.carModelObj.speed = this.formValue.value.speed;
    this.carModelObj.color = this.formValue.value.color;
    this.api.postCar(this.carModelObj).subscribe(
      res => {
        console.log(res);
        alert("Car Added !");
        this.getAllCars();
        let close = document.getElementById("cancel");
        close?.click();
        this.formValue.reset();

      },
      err => {
        alert("something went wrong !");
        this.getAllCars();

      }
    )
  }

  getAllCars() {
    this.api.getAllCar().subscribe(
      res => {
        this.carData = res
      }
    )
  }

  deleteCar(car: any) {
    this.api.deleteCar(car.id).subscribe(
      res => {
        alert("Car deleted");
        this.getAllCars();
      }
    )
  }


  editCar(data: any) {

    this.carModelObj.id = data.id;
    this.showAdd=false;
    this.showUpdate=true;
    this.formValue.controls['image'].setValue(data.image);
    this.formValue.controls['name'].setValue(data.name);
    this.formValue.controls['model'].setValue(data.model);
    this.formValue.controls['speed'].setValue(data.speed);
    this.formValue.controls['color'].setValue(data.color);
  }

  updateCarDetails() {
    this.carModelObj.image = this.formValue.value.image;
    this.carModelObj.name = this.formValue.value.name;
    this.carModelObj.model = this.formValue.value.model;
    this.carModelObj.speed = this.formValue.value.speed;
    this.carModelObj.color = this.formValue.value.color;


    this.api.updateCar(this.carModelObj, this.carModelObj.id).subscribe(
      res => {
        console.log(res);
        alert("Car dets edited successfully!");
        this.getAllCars();
        let close = document.getElementById("cancel");
        close?.click();
        this.formValue.reset();

      },
      err => {
        alert("something went wrong !");
        this.getAllCars();

      }
    )
  }
}

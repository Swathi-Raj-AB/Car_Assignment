export class CarModel{
    
    id:number=0;
    image:string='';
    name:string='';
    model:string='';
    speed:number=0;
    color:string='';
}
